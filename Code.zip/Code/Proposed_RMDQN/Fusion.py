import numpy as np


def callmain(Fea, O1, weight, Alpha=0.5):

    Fea = np.asarray(Fea, dtype=np.float64)
    O1 = np.asarray(O1, dtype=np.float64)

    # ---------------------------------------------------------
    # Selected feature groups
    # ---------------------------------------------------------

    G = [
        Fea[:, 1],
        Fea[:, 2],
        Fea[:, 4],
        Fea[:, 5],
        Fea[:, 6],
        Fea[:, 8],
        Fea[:, 9],
        Fea[:, 10]
    ]

    F3 = Fea[:, 3]
    F7 = Fea[:, 7]

    # ---------------------------------------------------------
    # Previous/output value
    # ---------------------------------------------------------

    if O1.size > 0:
        previous_output = O1.flat[0]
    else:
        previous_output = 0.0

    # ---------------------------------------------------------
    # Fractional feature transformation
    # ---------------------------------------------------------

    data = []

    for i in range(len(G)):

        temp = []

        for j in range(len(G[i])):

            y = G[i][j] * weight
            y1 = F3[j] * weight
            y2 = F7[j] * weight

            O2 = (
                Alpha * y
                + (Alpha / 2.0) * y1
                + ((1.0 - Alpha) / 6.0) * y2
                + (
                    Alpha
                    * (1.0 - Alpha)
                    * (2.0 - Alpha)
                    / 24.0
                ) * previous_output
            )

            temp.append(O2)

        data.append(temp)

    return np.asarray(data)