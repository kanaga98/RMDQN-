import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split


def classify(Fea,tr,label):

    X_train, X_test, y_train, y_test = train_test_split(Fea, label, train_size=tr,random_state=1)



    reg=LinearRegression().fit(X_train, y_train)
    Prediction=reg.predict(Fea)


    return np.array(Prediction).flatten()


