import tensorflow as tf
import numpy as np
from sklearn.model_selection import train_test_split

def qdnn_classify(
        Fea,
        O2,
        Label,
        tr,
        ACC,
        SEN,
        SPE):

    # Convert input to NumPy

    Fea = np.asarray(Fea, dtype=np.float32)
    Label = np.asarray(Label)

    # Apply O2 fractional output as feature weighting

    O2 = np.asarray(O2, dtype=np.float32).reshape(-1)

    if len(O2) == 1:

        Data = Fea * O2[0]

    else:

        if len(O2) != len(Fea):

            raise ValueError(
                "Length of O2 must be 1 or equal to number of samples."
            )

        Data = Fea * O2[:, np.newaxis]


    # Remove invalid values

    Data = np.nan_to_num(
        Data,
        nan=0.0,
        posinf=0.0,
        neginf=0.0
    )

    # ========================================================
    # Train / Test split
    # ========================================================

    x_train, x_test, y_train, y_test = train_test_split(
        Data,
        Label,
        train_size=tr,
        random_state=0,
        stratify=Label
    )

    # Convert to arrays
    x_train = np.asarray(x_train, dtype=np.float32)
    x_test = np.asarray(x_test, dtype=np.float32)

    y_train = np.asarray(y_train)
    y_test = np.asarray(y_test)

    # ========================================================
    # Feature normalization
    # ========================================================

    scaler = StandardScaler()

    x_train = scaler.fit_transform(
        x_train
    ).astype(np.float32)

    x_test = scaler.transform(
        x_test
    ).astype(np.float32)

    # ========================================================
    # Label encoding
    # ========================================================

    unique_labels = np.unique(
        np.concatenate([y_train, y_test])
    )

    label_map = {
        label: index
        for index, label in enumerate(unique_labels)
    }

    y_train_encoded = np.array([
        label_map[label]
        for label in y_train
    ])

    y_test_encoded = np.array([
        label_map[label]
        for label in y_test
    ])

    num_classes = len(unique_labels)

    # ========================================================
    # Build RNFQN
    # ========================================================

    model = build_RNFQN(
        input_dim=x_train.shape[1],
        num_classes=num_classes
    )

    # ========================================================
    # Train RNFQN
    # ========================================================

    history = model.fit(
        x_train,
        y_train_encoded,
        epochs=20,
        batch_size=16,
        validation_split=0.20,
        shuffle=True,
        verbose=1
    )

    # ========================================================
    # Prediction
    # ========================================================

    probability = model.predict(
        x_test,
        verbose=0
    )

    if num_classes == 2:

        probability = probability.reshape(-1)

        pred = (
            probability >= 0.5
        ).astype(int)

    else:

        pred = np.argmax(
            probability,
            axis=1
        )

    # ========================================================
    # Metrics
    # ========================================================

    if num_classes == 2:

        tp = np.sum(
            (y_test_encoded == 1) &
            (pred == 1)
        )

        tn = np.sum(
            (y_test_encoded == 0) &
            (pred == 0)
        )

        fp = np.sum(
            (y_test_encoded == 0) &
            (pred == 1)
        )

        fn = np.sum(
            (y_test_encoded == 1) &
            (pred == 0)
        )

        acc = (
            (tp + tn) /
            max(tp + tn + fp + fn, 1)
        )

        sen = (
            tp /
            max(tp + fn, 1)
        )

        spe = (
            tn /
            max(tn + fp, 1)
        )

    else:

        # Macro-average one-vs-rest sensitivity/specificity
        sensitivities = []
        specificities = []

        for c in range(num_classes):

            tp = np.sum(
                (y_test_encoded == c) &
                (pred == c)
            )

            tn = np.sum(
                (y_test_encoded != c) &
                (pred != c)
            )

            fp = np.sum(
                (y_test_encoded != c) &
                (pred == c)
            )

            fn = np.sum(
                (y_test_encoded == c) &
                (pred != c)
            )

            sensitivities.append(
                tp / max(tp + fn, 1)
            )

            specificities.append(
                tn / max(tn + fp, 1)
            )

        acc = np.mean(
            y_test_encoded == pred
        )

        sen = np.mean(sensitivities)

        spe = np.mean(specificities)

    ACC.append(acc)
    SEN.append(sen)
    SPE.append(spe)

    return (
        pred,
        y_test_encoded,
        probability,
        history,
        model
    )