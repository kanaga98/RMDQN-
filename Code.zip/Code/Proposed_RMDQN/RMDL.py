import numpy as np
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras.layers import (
    Input, Dense, Dropout, Conv1D, LSTM, GlobalMaxPooling1D,
    Concatenate, BatchNormalization
)
from tensorflow.keras.models import Model
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from Main.Initial_processing import process_Text



# RNFQN: RMDL + Quantum Neural Network-inspired fusion model

def RNFQN(input_dim, num_classes=2):

    inputs = Input(shape=(input_dim,), name="fused_features")

    # --------------------------------------------------------
    # RMDL Branch 1: Dense representation
    # --------------------------------------------------------
    dense_branch = Dense(
        256,
        activation="relu",
        name="RMDL_Dense_1"
    )(inputs)

    dense_branch = BatchNormalization()(dense_branch)
    dense_branch = Dropout(0.30)(dense_branch)

    dense_branch = Dense(
        128,
        activation="relu",
        name="RMDL_Dense_2"
    )(dense_branch)

    # --------------------------------------------------------
    # RMDL Branch 2: CNN representation
    # --------------------------------------------------------
    cnn_input = tf.expand_dims(inputs, axis=-1)

    cnn_branch = Conv1D(
        filters=64,
        kernel_size=3,
        padding="same",
        activation="relu",
        name="RMDL_CNN_1"
    )(cnn_input)

    cnn_branch = Conv1D(
        filters=32,
        kernel_size=3,
        padding="same",
        activation="relu",
        name="RMDL_CNN_2"
    )(cnn_branch)

    cnn_branch = GlobalMaxPooling1D()(cnn_branch)

    # --------------------------------------------------------
    # RMDL Branch 3: LSTM representation
    # --------------------------------------------------------
    lstm_input = tf.expand_dims(inputs, axis=-1)

    lstm_branch = LSTM(
        64,
        return_sequences=False,
        name="RMDL_LSTM"
    )(lstm_input)

    # --------------------------------------------------------
    # RMDL feature fusion
    # --------------------------------------------------------
    fused = Concatenate(name="RMDL_Feature_Fusion")([
        dense_branch,
        cnn_branch,
        lstm_branch
    ])

    fused = Dense(
        128,
        activation="relu",
        name="RMDL_Fused"
    )(fused)

    fused = Dropout(0.30)(fused)

    # --------------------------------------------------------
    # Quantum Neural Network-inspired layer
    #
    # Classical implementation of quantum-inspired
    # nonlinear transformation.
    # --------------------------------------------------------

    qnn = Dense(
        64,
        activation="tanh",
        name="Quantum_Encoding"
    )(fused)

    qnn = Dense(
        32,
        activation="sin",
        name="Quantum_Transformation"
    )(qnn)

    qnn = Dense(
        16,
        activation="tanh",
        name="Quantum_Entanglement"
    )(qnn)

    # --------------------------------------------------------
    # Output
    # --------------------------------------------------------

    if num_classes == 2:

        output = Dense(
            1,
            activation="sigmoid",
            name="Fake_News_Output"
        )(qnn)

        model = Model(
            inputs=inputs,
            outputs=output,
            name="RNFQN"
        )

        model.compile(
            optimizer=tf.keras.optimizers.Adam(
                learning_rate=0.001
            ),
            loss="binary_crossentropy",
            metrics=["accuracy"]
        )

    else:

        output = Dense(
            num_classes,
            activation="softmax",
            name="Fake_News_Output"
        )(qnn)

        model = Model(
            inputs=inputs,
            outputs=output,
            name="RNFQN"
        )

        model.compile(
            optimizer=tf.keras.optimizers.Adam(
                learning_rate=0.001
            ),
            loss="sparse_categorical_crossentropy",
            metrics=["accuracy"]
        )

    return model


# ============================================================
# Fake News Classification
# ============================================================

def classify(Tokenized_data, Label, tr=0.80):

    # --------------------------------------------------------
    # Feature preprocessing
    # --------------------------------------------------------

    Data, Label = process_Text(
        Tokenized_data,
        Label
    )

    Data = np.asarray(Data, dtype=np.float32)
    Label = np.asarray(Label)

    # --------------------------------------------------------
    # Remove invalid values
    # --------------------------------------------------------

    Data = np.nan_to_num(
        Data,
        nan=0.0,
        posinf=0.0,
        neginf=0.0
    )

    # --------------------------------------------------------
    # Train/Test split
    # --------------------------------------------------------

    X_train, X_test, y_train, y_test = train_test_split(
        Data,
        Label,
        train_size=tr,
        random_state=42,
        stratify=Label
    )

    # --------------------------------------------------------
    # Feature normalization
    # --------------------------------------------------------

    scaler = StandardScaler()

    X_train = scaler.fit_transform(X_train)
    X_test = scaler.transform(X_test)

    # --------------------------------------------------------
    # Number of classes
    # --------------------------------------------------------

    classes = np.unique(y_train)
    num_classes = len(classes)

    # Convert labels to 0/1 for binary classification
    if num_classes == 2:

        # Handle labels such as {0,1}, {-1,1}, etc.
        class_to_id = {
            cls: idx for idx, cls in enumerate(classes)
        }

        y_train_encoded = np.array([
            class_to_id[x] for x in y_train
        ])

        y_test_encoded = np.array([
            class_to_id[x] for x in y_test
        ])

    else:

        class_to_id = {
            cls: idx for idx, cls in enumerate(classes)
        }

        y_train_encoded = np.array([
            class_to_id[x] for x in y_train
        ])

        y_test_encoded = np.array([
            class_to_id[x] for x in y_test
        ])

    # --------------------------------------------------------
    # Build RNFQN
    # --------------------------------------------------------

    model = RNFQN(
        input_dim=X_train.shape[1],
        num_classes=num_classes
    )

    # --------------------------------------------------------
    # Train RNFQN
    # --------------------------------------------------------

    history = model.fit(
        X_train,
        y_train_encoded,
        epochs=30,
        batch_size=32,
        validation_split=0.20,
        verbose=1
    )

    # --------------------------------------------------------
    # Prediction
    # --------------------------------------------------------

    prediction_probability = model.predict(
        X_test,
        verbose=0
    )

    # --------------------------------------------------------
    # Convert probabilities into class predictions
    # --------------------------------------------------------

    if num_classes == 2:

        prediction = (
            prediction_probability.ravel() >= 0.5
        ).astype(int)

    else:

        prediction = np.argmax(
            prediction_probability,
            axis=1
        )

    # --------------------------------------------------------
    # Accuracy
    # --------------------------------------------------------

    test_loss, test_accuracy = model.evaluate(
        X_test,
        y_test_encoded,
        verbose=0
    )

    # --------------------------------------------------------
    # Weight information
    # --------------------------------------------------------

    weights = model.get_weights()

    weight_values = []

    for w in weights:

        if w.size > 0:
            weight_values.append(
                np.mean(np.abs(w))
            )

    mean_weight = np.mean(weight_values)


    return (
        prediction,
        y_test_encoded,
        prediction_probability,
        history,
        test_accuracy,
        mean_weight,
        model
    )