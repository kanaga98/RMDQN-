import Initial_processing
import BERT_Tokenizer
import Fea_Ext
import Proposed_RMDQN.RMDL
import Proposed_RMDQN.Fusion
import Proposed_RMDQN.Regression
import Proposed_RMDQN.DQNN
import DeepCNN.DCNN
import NN.nn
import RSSO_NN_GAN.run
import RNN.rnn
import Supervised_AI_algorithms.KLR

def callmain(tr):
    ACC,SEN,SPE=[],[],[]
    ACC1,SEN1,SPE1=[],[],[]
    path="dataset/fakenews"
    Data=Initial_processing.callmain(path) # Preprocessing
    Token_data=BERT_Tokenizer.callmain(Data)
    Fea,Label,Label1=Fea_Ext.callmain(Token_data)
    # fake News Detection
    O1,Weight=Proposed_RMDQN.RMDL.classify(Token_data, Label, tr)
    F=Proposed_RMDQN.Fusion.callmain(Fea, O1, Weight)
    O2=Proposed_RMDQN.Regression.classify(F, tr, Label)
    y_Pred=Proposed_RMDQN.DQNN.qdnn_classify(Fea, O2, Label, tr, ACC1, SEN1, SPE1)
    #-----------------Comparative Method-------------------
    y_pred1=RSSO_NN_GAN.run.prop_run(Fea, Label, tr, ACC1, SEN1, SPE1)
    y_pred2=DeepCNN.DCNN.classify(Fea,Label,tr,ACC1,SEN1,SPE1)
    y_pred3=NN.nn.classify(Fea,Label,tr,ACC1,SEN1,SPE1)
    y_pred4=RNN.rnn.classify(Fea,Label,tr,ACC1,SEN1,SPE1)
    y_pred5=Supervised_AI_algorithms.KLR.classify(Fea,Label,tr,ACC1,SEN1,SPE1)

    # Fake Impact Identification
    L1,Weight=Proposed_RMDQN.RMDL.classify(Token_data, Label1, tr)
    F = Proposed_RMDQN.Fusion.callmain(Fea, L1, Weight)
    L2 = Proposed_RMDQN.Regression.classify(F, tr, Label1)
    Proposed_RMDQN.DQNN.qdnn_classify(y_Pred, L2, Label1, tr, ACC, SEN, SPE)
    #---------------Comparative Method--------------
    RSSO_NN_GAN.run.prop_run(y_pred1, Label1, tr, ACC, SEN, SPE)
    DeepCNN.DCNN.classify(y_pred2, Label1, tr, ACC, SEN, SPE)
    NN.nn.classify(y_pred3, Label1, tr, ACC, SEN, SPE)
    RNN.rnn.classify(y_pred4, Label1, tr, ACC, SEN, SPE)
    Supervised_AI_algorithms.KLR.classify(y_pred5, Label1, tr, ACC, SEN, SPE)


    return ACC,SEN,SPE

