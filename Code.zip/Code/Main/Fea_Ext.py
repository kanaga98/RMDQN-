from sklearn.feature_extraction.text import TfidfVectorizer
from nltk.corpus import wordnet as wn
from nltk.corpus import wordnet_ic
from textblob import TextBlob
import pandas as pd
import numpy as np
import re
# Title

def title_fea(sentence):
    title_C=0
    for char in sentence:

        if char==char.title():
            title_C += 1

    return title_C
#Numerical Sentence
def Num_Sent(sentence):
    num_sent=0
    for char in sentence:

        if char.isdigit():
            num_sent += 1

    return num_sent



# TF-IDF
def TF_IDF(sentence):


    vectorizer = TfidfVectorizer()
    X = vectorizer.fit_transform(sentence)
    x = X.toarray()
    #x=x[0][0:5]
    x = np.mean(x, axis=1)
    return np.mean(x)

# Word Count
def word_count(sentence):
    word=0
    for words in sentence:
        word+=1
    return word


# Sentence count
def sen_count(sentence):
    count=0
    if '.' in sentence:
        count+=1
    return count

#  Average word length
def Average_word_length(sentence):
    word_ln=[]
    for i in range(len(sentence)):
        length=len(sentence[i])
        word_ln.append(length)
    return np.average(word_ln)


#Lin similarity score
def lin_similarity(words):
    semcor_ic = wordnet_ic.ic('ic-semcor.dat')
    n = []
    for i in range(len(words)):

        try:
            n1 = words[i]
            n2 = words[i + 1]
            l_sim = wn.synset(n1 + '.n.01').lin_similarity(wn.synset(n2 + '.n.01'), semcor_ic)
            n.append(l_sim)
        except:
            n.append(0)

    return np.mean(n)

# Sentiword net
def get_senti_score(sentences):
    positive , negative = [],[]

    for i in range(len(sentences)):
        pos, neg = 0, 0

        sentiment = ""
        language = 'en'

        sentiment = TextBlob(str(sentences[i]))  # processing text
        Senti_core = sentiment.sentiment.polarity  # score calculation
        if Senti_core > 0:  # positive score
            pos += 1
        else:               # negative score
            neg += 1
        positive.append(pos)
        negative.append(neg)
    return np.mean(positive), np.mean(negative)

# Punctuation
def get_punctuation(sentence):

    punctuations = '''!()-[]{};:'"\,<>./?@#$%^&*_~'''
    punct_count = 0
    for char in sentence:
        if char in punctuations:
            punct_count += 1
    return punct_count

 # Emoticons
def emotions(text):
    text = str(text)
    emot1 = []
    emot2 = []
    for feedback in text:
        feedback_polarity = TextBlob(feedback).sentiment.polarity
        if feedback_polarity > 0:
            emot1.append(feedback)
            continue
        emot2.append(feedback)

    Emotions = len(emot1) + len(emot2)
    eyes, noses, mouths = r":;8BX=", r"-~'^", r")(/\|DP"
    pattern1 = "[%s][%s]?[%s]" % tuple(map(re.escape, [eyes, noses, mouths]))

    smileys = """:-) :) :o) :] :3 :c) :> =] 8) =) :} :^) 
                 :D 8-D 8D x-D xD X-D XD =-D =D =-3 =3 B^D""".split()
    pattern2 = "|".join(map(re.escape, smileys))
    if (len(re.findall(pattern1, text)) > 0):
        count = len(re.findall(pattern1, text))
    elif (len(re.findall(pattern2, text)) > 0):
        count = len(re.findall(pattern2, text))
    elif Emotions > 0:
        count = Emotions

    return count

# Elongated
def get_elongated_words(sentence):

    elong = re.compile("([a-zA-Z])\\1{2,}")
    count = 0
    for i in range(len(sentence)):
        a = bool(elong.search(sentence[i]))  # boolean true if word is elongated
        if a is True:
            count += 1
    return count
# Numerical words

def NW(sentence):

    NW_count = 0
    for char in sentence:
        if char.isdigit():
            NW_count += 1
    return NW_count
#All caps
def n_upper_chars(string):

    return sum(map(str.isupper, string))



def fea(Tokenized_data):
    Fea=[]

    for i in range(len(Tokenized_data)):
        sen=Tokenized_data[i]
        print('i :',i)
        #print('i :',sen)

        f1=title_fea(sen)

        f2=Num_Sent(sen)

        f3=TF_IDF(sen)

        f4=word_count(sen)

        f5=sen_count(sen)

        f6=Average_word_length(sen)

        f7=lin_similarity(sen)

        f81,f82=get_senti_score(sen)

        f9=get_punctuation(sen)

        f10=emotions(Tokenized_data[i])

        f11=get_elongated_words(sen)

        f12=NW(sen)

        f13=n_upper_chars(sen)


        F=[f1,f2,f3,f4,f5,f6,f7,f81,f82,f9,f10,f11,f12,f13]

        Fea.append(F)

        np.savetxt("Processed/Features.csv",Fea,delimiter=',',fmt='%s')



def callmain(Tokenized_data):

    #fea(Tokenized_data)

    Feature=pd.read_csv("Processed/Features.csv",header=None)
    Feature=np.array(Feature)
    Label=pd.read_csv("Processed/fakenews_class.csv",header=None)
    Label=np.array(Label)

    return Feature,Label
