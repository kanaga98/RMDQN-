from transformers import BertTokenizer
import numpy as np

def Tokenize(datas):

    data = []
    for i in range(len(datas)):
        tz = BertTokenizer.from_pretrained("bert-base-cased")
        tz.convert_tokens_to_ids(["characteristically"])
        data.append(tz.tokenize(datas[i]))
    np.savetxt('Processed//fakenews_Tokenized_data.csv', data, delimiter=',', fmt='%s',encoding='utf-8')  # write preprocessed data
    return data


def callmain(datas):

    #Tokenize(datas)

    import csv
    Tok_data=[]
    with open('Processed//fakenews_Tokenized_data.csv', mode='r',encoding='utf-8')as file:
        csvFile = csv.reader(file)
        for lines in csvFile:
            Tok_data.append(lines)

    return Tok_data
