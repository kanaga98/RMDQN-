from Main import Initial_processing, Feature_Extraction, read

def process(dts):
    print('\n Tokenization...')
    print("\n Feature Extraction...")
    def extract():
        #preprocess.preprocessing(dts) # Preprocessing
        data = read.read_data(dts) # read data
        Feature_Extraction.feature(data,dts) # Feature Extraction
    #extract()