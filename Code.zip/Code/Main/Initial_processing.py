import os
import numpy as np
import csv


def process(x_path):
    a = []
    folder = os.listdir(x_path)  # list the folders inside the path
    for file in folder:
        y_path = x_path + "/" + file  # the path of sub-folders
        sub_folder = os.listdir(y_path)  # list the files inside the sub-folders
        for j in sub_folder:
            z = y_path + "//" + j
            ff = os.listdir(z)
            for k in ff:
                aa = y_path + "//" + j + '//' + k
                a.append(aa)
    line=[]
    lab = []
    for i in range(len(a)):
        aa = a[i]
        with open(aa, 'r', encoding='utf-8') as f:
            contents = f.readlines()
            if len(contents)>0:
                line.append(contents)

            if 'real' in a[i] : lab.append(1)
            elif 'fake' in a[i] : lab.append(0)
    lines = []

    for i in range(len(line)):
        a = '\n'
        l = line[i]
        for i in range(len(l)):
            if a in l:
                l.remove('\n')
        x = [s.rstrip() for s in l]
        lines.append(x)
    n = 'Processed//fakenews.csv'
    with open(n, 'w',newline='', encoding='utf-8') as file:
        writer = csv.writer(file)
        writer.writerows(lines)
    np.savetxt("Processed//fakenews.txt", lines, fmt='%s',encoding='utf-8')
    np.savetxt("Processed//fakenews_class.csv", lab, fmt='%s')
    data = []
    for i in range(len(lines)):
        x = [s.rstrip() for s in lines[i]]
        x = (str(x).strip('[]'))
        data.append(x)
    print(len(data))


    return data



def callmain(path):

    #process(path)

    file = open('Processed/fakenews.txt', "r", encoding='utf-8')

    datas = file.readlines()
    file.close()
    return datas

